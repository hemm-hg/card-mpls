document.addEventListener('DOMContentLoaded', function() {
    // Theme Toggle
    const themeBtn = document.getElementById('theme-btn');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Set initial theme based on preference
    if (prefersDarkScheme.matches) {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeBtn.textContent = '☀️';
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        themeBtn.textContent = '🌙';
    }
    
    // Toggle theme on button click
    themeBtn.addEventListener('click', function() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        if (currentTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'light');
            themeBtn.textContent = '🌙';
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            themeBtn.textContent = '☀️';
        }
    });
    
    // Dynamic Date
    function updateDate() {
        const now = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        document.getElementById('current-date').textContent = now.toLocaleDateString('en-US', options);
    }
    updateDate();
    setInterval(updateDate, 60000); // Update every minute
    
    // Typing Animation for Name
    function typeWriter(element, text, speed) {
        let i = 0;
        element.innerHTML = '';
        
        function typing() {
            if (i < text.length) {
                element.innerHTML += text.charAt(i);
                i++;
                setTimeout(typing, speed);
            } else {
                // Add blinking cursor after typing is done
                element.innerHTML += '<span class="cursor"></span>';
            }
        }
        
        typing();
    }
    
    typeWriter(document.getElementById('typed-name'), 'Gurat Lucky Wicaksono', 100);
    
    // Motivational Quotes
    const quotes = [
        "Education is the most powerful weapon which you can use to change the world. - Nelson Mandela",
        "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
        "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
        "Believe you can and you're halfway there. - Theodore Roosevelt",
        "The only way to do great work is to love what you do. - Steve Jobs"
    ];
    
    let currentQuoteIndex = 0;
    const quoteElement = document.getElementById('dynamic-quote');
    
    function displayNextQuote() {
        quoteElement.style.opacity = 0;
        
        setTimeout(() => {
            currentQuoteIndex = (currentQuoteIndex + 1) % quotes.length;
            quoteElement.textContent = quotes[currentQuoteIndex];
            quoteElement.style.opacity = 1;
        }, 500);
    }
    
    // Display first quote immediately
    quoteElement.textContent = quotes[currentQuoteIndex];
    quoteElement.style.opacity = 1;
    
    // Change quote every 10 seconds
    setInterval(displayNextQuote, 10000);
    
    // Create Animated Stars
    function createStars() {
        const starBackground = document.querySelector('.star-background');
        const starCount = window.innerWidth < 768 ? 30 : 50;
        
        for (let i = 0; i < starCount; i++) {
            const star = document.createElement('div');
            star.classList.add('star');
            
            // Random size between 1-3px
            const size = Math.random() * 2 + 1;
            star.style.width = `${size}px`;
            star.style.height = `${size}px`;
            
            // Random position
            star.style.left = `${Math.random() * 100}%`;
            star.style.top = `${Math.random() * 100}%`;
            
            // Random animation duration (5-15s) and delay (0-5s)
            const duration = Math.random() * 10 + 5;
            const delay = Math.random() * 5;
            star.style.animation = `float ${duration}s linear ${delay}s infinite`;
            
            starBackground.appendChild(star);
        }
    }
    
    createStars();
    
    // Create Shooting Stars in Footer
    function createShootingStar() {
        const footer = document.querySelector('.glass-footer');
        const shootingStar = document.createElement('div');
        shootingStar.classList.add('shooting-star');
        
        // Random position and delay
        shootingStar.style.top = `${Math.random() * 50}%`;
        shootingStar.style.animationDelay = `${Math.random() * 5}s`;
        
        footer.appendChild(shootingStar);
        
        // Remove after animation completes
        setTimeout(() => {
            shootingStar.remove();
        }, 5000);
    }
    
    // Create initial shooting stars
    for (let i = 0; i < 3; i++) {
        setTimeout(createShootingStar, i * 2000);
    }
    
    // Continue creating shooting stars periodically
    setInterval(createShootingStar, 5000);
    
    // Gallery Image Interaction
    const galleryImages = document.querySelectorAll('.gallery-img');
    galleryImages.forEach(img => {
        img.addEventListener('click', function() {
            // Create a temporary focus effect
            this.style.transform = 'scale(1.1)';
            this.style.transition = 'transform 0.3s';
            
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 300);
        });
        
        // Touch support
        img.addEventListener('touchstart', function() {
            this.style.transform = 'scale(0.95)';
        });
        
        img.addEventListener('touchend', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Neumorphism effect for cards in light mode
    function applyNeumorphism() {
        const cards = document.querySelectorAll('.glass-card');
        const currentTheme = document.documentElement.getAttribute('data-theme');
        
        cards.forEach(card => {
            if (currentTheme === 'light') {
                card.style.boxShadow = `
                    8px 8px 16px rgba(0, 0, 0, 0.1),
                    -8px -8px 16px rgba(255, 255, 255, 0.5)
                `;
            } else {
                card.style.boxShadow = `
                    8px 8px 16px rgba(0, 0, 0, 0.3),
                    -8px -8px 16px rgba(255, 255, 255, 0.05)
                `;
            }
        });
    }
    
    // Apply initially and when theme changes
    applyNeumorphism();
    themeBtn.addEventListener('click', applyNeumorphism);
    
    // Handle window resize
    window.addEventListener('resize', function() {
        // Recreate stars for responsive adjustment
        document.querySelector('.star-background').innerHTML = '';
        createStars();
    });
});